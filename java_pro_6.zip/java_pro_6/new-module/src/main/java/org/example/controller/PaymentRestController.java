package org.example.controller;

import lombok.RequiredArgsConstructor;
import org.example.controller.dto.ProductDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClient;

import java.util.List;

@RestController
@RequestMapping("org/payment")
@RequiredArgsConstructor(onConstructor_ = {@Autowired})
class PaymentRestController {

    private final RestClient restClient;

    @GetMapping("/{id}/getAllProducts")
    public ResponseEntity<List<ProductDto>> getAllProducts(@PathVariable String id) {
        List<ProductDto> productDtoList = restClient.get()
                .uri("http://localhost:8090/org/example/" + id + "/getAllProducts", ProductDto.class)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .body(new ParameterizedTypeReference<>() {});

        return ResponseEntity.ok().body(productDtoList);
        }

    @GetMapping("/getProduct")
    public ResponseEntity<ProductDto> getProductByProductId(@RequestParam String productId) {
        ProductDto productDto = restClient.get()
                .uri("http://localhost:8090/org/example/getProduct?productId=" + productId, ProductDto.class)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .body(new ParameterizedTypeReference<>() {});

        return ResponseEntity.ok().body(productDto);
    }
}
