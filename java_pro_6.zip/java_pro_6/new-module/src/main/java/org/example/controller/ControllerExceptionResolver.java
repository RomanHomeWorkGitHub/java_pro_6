package org.example.controller;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.stereotype.Component;
import org.springframework.util.ClassUtils;

@Component
public class ControllerExceptionResolver {

    public ErrorParams convert(Exception exception) {
        int statusCode;
        String description;

        if (isAssignable(exception, ClassNotFoundException.class)) {

            statusCode = HttpStatus.NOT_FOUND.value();
            description = exception.getMessage();

        } else if (isAssignable(exception, HttpMessageNotReadableException.class)) {

            statusCode = HttpStatus.BAD_REQUEST.value();
            description = "Отсутствует или нечитаемое тело запроса: " + exception.getMessage();

        } else if (exception.getClass().getName().contains("SQLException") ||
            (exception.getCause() != null && exception.getCause().getClass().getName().contains("SQLException"))) {

            statusCode = HttpStatus.INTERNAL_SERVER_ERROR.value();
            description = "Ошибка работы с БД: " + exception.getMessage();
        } else {

            statusCode = HttpStatus.INTERNAL_SERVER_ERROR.value();
            description = "Внутренняя ошибка сервера";
        }

        return ErrorParams.builder()
            .statusCode(statusCode)
            .description(description)
            .build();
    }

    private boolean isAssignable(Throwable e, Class<? extends Exception> toClass) {
        return ClassUtils.isAssignable(e.getClass(), toClass);
    }

    @Builder
    @Getter
    @FieldDefaults(level = AccessLevel.PRIVATE)
    public static class ErrorParams {
        String description;
        int statusCode;
    }
}

