package org.example.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.example.model.Product;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProductDto {
    Long id;
    String account_number;
    BigDecimal balance;
    Product.ProducTypeEnum product_type;

    public ProductDto(Long id, String account_number, BigDecimal balance, String product_type) {
        this.id = id;
        this.account_number = account_number;
        this.balance = balance;
        this.product_type = setProduct_type(product_type);;
    }

    public ProductDto(Product product) {
        this.id = product.getId();
        this.account_number = product.getAccount_number();
        this.balance = product.getBalance();
        this.product_type = product.getProduct_type();
    }

    public org.example.model.Product.ProducTypeEnum setProduct_type(String product_type) {
        if (product_type.equals("ACC")) {return this.product_type = org.example.model.Product.ProducTypeEnum.ACC;}
        else if (product_type.equals("CRD")) {return this.product_type = org.example.model.Product.ProducTypeEnum.CRD;}
        else throw new IllegalArgumentException("Invalid product type: " + product_type);
    }
}
