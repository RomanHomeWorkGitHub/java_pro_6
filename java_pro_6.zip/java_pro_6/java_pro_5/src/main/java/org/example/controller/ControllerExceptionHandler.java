package org.example.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestControllerAdvice
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class ControllerExceptionHandler extends ResponseEntityExceptionHandler {

    private final ControllerExceptionResolver exceptionResolver;

    @ExceptionHandler({Exception.class})
    public ResponseEntity handleError(Exception exception) {

        ControllerExceptionResolver.ErrorParams params = exceptionResolver.convert(exception);

        return ResponseEntity
            .status(params.getStatusCode())
            .body(params.getDescription());
    }
}