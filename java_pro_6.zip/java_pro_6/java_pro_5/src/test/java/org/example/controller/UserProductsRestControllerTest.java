package org.example.controller;


import org.example.dao.ProductDao;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean;
import org.springframework.test.web.servlet.MockMvc;

import java.sql.SQLException;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doThrow;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest()
@AutoConfigureMockMvc()
class UserProductsRestControllerTest {

    @Autowired
    MockMvc mockMvc;

    @MockitoSpyBean
    ProductDao productDao;

    @Test
    void getAllProducts_SqlException() throws Exception {
        doThrow(new RuntimeException(new SQLException("SQLException")))
                .when(productDao).getAllProducts(anyLong());

        mockMvc.perform(get( "/org/example/{id}/getAllProducts", 1))
                .andExpect(status().isInternalServerError())
                .andDo(print());
    }

    @Test
    void getAllProducts_badRequest() throws Exception {
        mockMvc.perform(get( "/org/example/{id}/getAllProducts", "@"))
                .andExpect(status().isInternalServerError())
                .andDo(print());
    }

    @Test
    void getAllProducts_ok() throws Exception {
        mockMvc.perform(get( "/org/example/{id}/getAllProducts", 1))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$.[0].id","id").value(1))
                .andExpect(jsonPath("$.[0].account_number","account_number").value("C12345"))
                .andExpect(jsonPath("$.[0].balance","balance").value(100))
                .andExpect(jsonPath("$.[0].product_type","product_type").value("CRD"))
                .andExpect(jsonPath("$.[1].id","id").value(2))
                .andExpect(jsonPath("$.[1].account_number","account_number").value("C23451"))
                .andExpect(jsonPath("$.[1].balance","balance").value(101))
                .andExpect(jsonPath("$.[1].product_type","product_type").value("CRD"))
                .andDo(print());
    }

    @Test
     void getProductByProductId_badRequest() throws Exception {
        mockMvc.perform(get( "/org/example/getProduct").param("test", "1"))
                .andExpect(status().isBadRequest())
                .andDo(print());
    }

    @Test
     void getProductByProductId_ok() throws Exception {
        mockMvc.perform(get( "/org/example/getProduct").param("productId", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id","id").value(1))
                .andExpect(jsonPath("$.account_number","account_number").value("C12345"))
                .andExpect(jsonPath("$.balance","balance").value(100))
                .andExpect(jsonPath("$.product_type","product_type").value("CRD"))
                .andDo(print());
    }
}