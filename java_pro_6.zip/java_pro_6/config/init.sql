CREATE TABLE users (id bigserial primary key, username varchar(255) unique);
CREATE TABLE product (id bigserial primary key, account_number varchar(255) unique, balance decimal, product_type varchar(3));
CREATE TABLE PrdctUsrDscrptn (id bigserial, account_number varchar(255) unique, user_id bigserial);

INSERT INTO users (id, username)
VALUES (1, 'Вася1'),
       (2, 'Вася2'),
       (3, 'Вася3');
INSERT INTO product (id, account_number, balance, product_type)
VALUES (1, 'C12345', 100, 'CRD'),
       (2, 'C23451', 101, 'CRD'),
     (3, 'A34512', 102, 'ACC'),
     (4, 'C45123', 110, 'CRD'),
     (5, 'A51234', 111, 'ACC');
INSERT INTO prdctUsrDscrptn (id, account_number, user_id)
VALUES (1, 'C12345', 1),
     (2, 'C23451', 1),
     (3, 'A34512', 2),
     (4, 'C45123', 2),
     (5, 'A51234', 3);
