package org.example.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Product {

    Long id;
    String account_number;
    BigDecimal balance;
    ProducTypeEnum product_type;

    public Product(Long id, String account_name, BigDecimal balance, String product_type) {
        this.id = id;
        this.account_number = account_name;
        this.balance = balance;
        this.product_type = setProduct_type(product_type);;
    }

    public enum ProducTypeEnum  {
        ACC, CRD;
    }

    public ProducTypeEnum setProduct_type(String product_type) {
        if (product_type.equals("ACC")) {return this.product_type = ProducTypeEnum.ACC;}
        else if (product_type.equals("CRD")) {return this.product_type = ProducTypeEnum.CRD;}
        else throw new IllegalArgumentException("Invalid product type: " + product_type);
    }
}
