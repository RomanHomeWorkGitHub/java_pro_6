package org.example.dao;

import jakarta.annotation.PreDestroy;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.example.mapper.ProductMapper;
import org.example.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

@Repository
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class ProductDao {

    private final ProductMapper productMapper;

    private final Connection connection;

    @PreDestroy
    void close() throws SQLException {
        connection.close();
    }

    public List<Product> getAllProducts(Long id) {
        try (PreparedStatement pst = connection.prepareStatement("SELECT * FROM product WHERE id IN (SELECT id FROM prdctusrdscrptn WHERE user_id = ?)")) {
            pst.setLong(1, id);
            return productMapper.mapToProduct(pst.executeQuery());
       } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Product getProductByProductId(Long id) throws SQLException {
        try (PreparedStatement pst = connection.prepareStatement("SELECT * FROM PRODUCT WHERE id = ?")) {
            pst.setLong(1, id);
            return productMapper.mapToProduct(pst.executeQuery()).get(0);
        }
    }
}
