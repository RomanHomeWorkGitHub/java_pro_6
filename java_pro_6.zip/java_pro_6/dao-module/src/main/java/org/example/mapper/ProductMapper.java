package org.example.mapper;

import org.example.model.Product;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Component
public class ProductMapper {

    public List<Product> mapToProduct(ResultSet resultSet) throws SQLException {
        List<Product> products = new ArrayList<>();
        while (resultSet.next()) {
            Product product = new Product(
                    resultSet.getLong("id"),
                    resultSet.getString("account_number"),
                    resultSet.getBigDecimal("balance"),
                    resultSet.getString("product_type"));
            products.add(product);
        }
        return products;
    }
}
