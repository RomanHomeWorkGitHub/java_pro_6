package org.example.dao;

import jakarta.annotation.PreDestroy;
import org.example.mapper.UserMapper;
import org.example.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

@Repository
public class UserDao {

    @Autowired
    UserMapper userMapper;

    @Autowired
    Connection connection;

    @PreDestroy
    void close() throws SQLException {
        connection.close();
    }

    public List<User> getUsers() throws SQLException {
       try (PreparedStatement pst = connection.prepareStatement("SELECT * FROM users")) {
            return userMapper.mapToUser(pst.executeQuery());
        }
    }

    public User getUserById(long id) throws SQLException {
        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM USERS WHERE id = ?")) {
            preparedStatement.setLong(1, id);
            return userMapper.mapToUser(preparedStatement.executeQuery()).get(0);
        }
    }

    public boolean createUser(User user) throws SQLException {
        try (PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO USERS(id, username) VALUES(?, ?)")) {
            preparedStatement.setLong(1, user.getId());
            preparedStatement.setString(2, user.getUsername());
            return preparedStatement.execute();
        }
    }

    public boolean updateUser(User user) throws SQLException {
        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE USERS SET username = ? WHERE id = ?")) {
            preparedStatement.setString(1, user.getUsername());
            preparedStatement.setLong(2, user.getId());
            return preparedStatement.execute();
        }
    }

    public boolean deleteUser(long id) throws SQLException {
        try (PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM USERS WHERE id = ?")) {
            preparedStatement.setLong(1, id);
            return preparedStatement.execute();
        }
    }
}
