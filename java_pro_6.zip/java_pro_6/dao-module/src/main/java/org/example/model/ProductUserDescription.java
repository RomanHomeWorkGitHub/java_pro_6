package org.example.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ProductUserDescription {
    Long product_id;
    String account_number;
    Long user_id;
}
